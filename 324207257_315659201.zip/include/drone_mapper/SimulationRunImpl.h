#pragma once

#include <drone_mapper/IDroneControl.h>
#include <drone_mapper/IDroneMovement.h>
#include <drone_mapper/IGPS.h>
#include <drone_mapper/ILidar.h>
#include <drone_mapper/IMap3D.h>
#include <drone_mapper/IMappingAlgorithm.h>
#include <drone_mapper/IMissionControl.h>
#include <drone_mapper/IMutableMap3D.h>
#include <drone_mapper/ISimulationRun.h>

#include <filesystem>
#include <memory>

namespace drone_mapper {

class SimulationRunImpl final : public ISimulationRun {
public:
    SimulationRunImpl(types::SimulationConfigData simulation_config,
                      types::MissionConfigData mission_config,
                      types::DroneConfigData drone_config,
                      types::LidarConfigData lidar_config,
                      types::ResolutionRequestStatus resolution_status,
                      std::unique_ptr<const IMap3D> hidden_map,
                      std::unique_ptr<IMutableMap3D> output_map,
                      std::unique_ptr<IGPS> gps,
                      std::unique_ptr<IDroneMovement> movement,
                      std::unique_ptr<ILidar> lidar,
                      std::unique_ptr<IMappingAlgorithm> mapping_algorithm,
                      std::unique_ptr<IDroneControl> drone_control,
                      std::unique_ptr<IMissionControl> mission_control,
                      std::filesystem::path output_map_file);

    [[nodiscard]] types::SimulationResult run() override;

private:
    types::SimulationConfigData simulation_config_;
    types::MissionConfigData mission_config_;
    types::DroneConfigData drone_config_;
    types::LidarConfigData lidar_config_;
    types::ResolutionRequestStatus resolution_status_;
    std::unique_ptr<const IMap3D> hidden_map_;
    std::unique_ptr<IMutableMap3D> output_map_;
    std::unique_ptr<IGPS> gps_;
    std::unique_ptr<IDroneMovement> movement_;
    std::unique_ptr<ILidar> lidar_;
    std::unique_ptr<IMappingAlgorithm> mapping_algorithm_;
    std::unique_ptr<IDroneControl> drone_control_;
    std::unique_ptr<IMissionControl> mission_control_;
    std::filesystem::path output_map_file_;
};

} // namespace drone_mapper
